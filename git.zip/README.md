# Projek Akhir - Praktikum SCPK


## Kelompok : 
\--- Kelas Prak SCPK IF-F \---
1. Akbar Ariffianto / 123220004
2. Wijdan Akhmad S / 123220010


### Keterangan :
Tema = Kecatikan \
Topik yang diambil = Memilih Kecantikan 

### Dokumen membantu : 
- [Link Laporan Akhir](https://docs.google.com/document/d/1r2Hy8lrGHNL7dDIXrjfMJa6GuMytnCFZ/edit?usp=sharing&ouid=105010364454172699863&rtpof=true&sd=true)
